
let ss = document.getElementById("karakter");
ss.style.position="releative";
ss.style.top="1px";
ss.style.left="1px";

ss.style.right="1px";

x = 0
y = 0

function movieFunctionileri(){
    
    let __ = x+=10 ;
let dd= document.getElementById("karakter");
dd.style.position="relative";
dd.style.top=__+"px";
if(x<0){
 
    dd.style.top="50px";
}
console.log(x)
}

function movieFunctiongeri(){
    let __ = x-=10 ;
let dd= document.getElementById("karakter");
dd.style.position="relative";
dd.style.top=__+"px";

console.log(x)
}
function movieFunctionsag(){
    let __ = y+=10 ;
let dd= document.getElementById("karakter");
dd.style.position="relative";
dd.style.left=__+"px";


console.log(y)
}

function movieFunctionsol(){
    let __ = y-=10 ;
let dd= document.getElementById("karakter");
dd.style.position="relative";
dd.style.left=__+"px";

console.log(y)
}

window.onkeydown=function(yön) {
    //yukarı asagı


if(yön.keyCode==40 || yön.keyCode==83)
{
    let __ = x+=10 ;
    let dd= document.getElementById("karakter");
    dd.style.position="relative";
    dd.style.top=__+"px";
    
    console.log(x)
}
else if(yön.keyCode==38 ||  yön.keyCode==87 )
{
    let __ = x-=10 ;
    let dd= document.getElementById("karakter");
    dd.style.position="relative";
    dd.style.top=__+"px";
    if(x<0){
 x= 0
        dd.style.top=x+"px";
    }

    console.log(x)
}

else if(yön.keyCode==39 || yön.keyCode==68 )
{
    let __ = y+=10 ;
    let dd= document.getElementById("karakter");
    dd.style.position="relative";
    dd.style.left=__+"px";
    if(y==1800){
        y = 0
               dd.style.left=x+"px";
           }
    console.log(y)
}


else if(yön.keyCode==37 || yön.keyCode==65)
{
    let __ = y-=10 ;
let dd= document.getElementById("karakter");
dd.style.position="relative";
dd.style.left=__+"px";
if(y==-30){
    y = 1800
           dd.style.left=y+"px";
       }
console.log(y)
}
}